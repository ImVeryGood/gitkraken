# v0.6.2 - Patches with Love :cupid:

- Support GitKraken v6.5.2
  - Pro
  - Individual
  - Enterprise
    - Self-Hosted
    - Stand-Alone
  - Modes
    - Development
    - Staging
- Bump dependencies

> Our greatest glory is not in never falling, but in getting up every time we do.

# v0.6.1 - Return of the missing patches

- Support GitKraken v6.0.0
  - Pro
  - Individual
  - Enterprise
    - Self-Hosted
    - Stand-Alone
  - Modes
    - Development
    - Staging
- Bump dependencies

# v0.6.0 - Lightspeed :rocket:

- Support GitKraken Pro v6.0.0
- Bump dependencies
